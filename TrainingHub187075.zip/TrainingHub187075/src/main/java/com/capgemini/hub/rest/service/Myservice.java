package com.capgemini.hub.rest.service;

import java.util.List;
import java.util.Optional;

import com.capgemini.hub.rest.model.Training;

public interface Myservice {

	public List<Training> getTrainings();
	public Optional<Training> getTrainingById(int empid);
	public Training addNewTraining(Training emp);
	public Training updateTraining(Training emp);
	public void deleteTrainingById(int empid);
	public void deleteAllTrainings();

}