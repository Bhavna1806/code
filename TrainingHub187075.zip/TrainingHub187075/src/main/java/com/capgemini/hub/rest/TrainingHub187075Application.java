package com.capgemini.hub.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingHub187075Application {

	public static void main(String[] args) {
		SpringApplication.run(TrainingHub187075Application.class, args);
	}

}
