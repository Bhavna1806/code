package com.capgemini.hub.rest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.hub.rest.model.Training;

@Repository
public interface Mydaorepository extends JpaRepository<Training, Integer> {

}