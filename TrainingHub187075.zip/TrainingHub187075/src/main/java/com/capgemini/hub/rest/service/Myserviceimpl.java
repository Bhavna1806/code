package com.capgemini.hub.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hub.rest.dao.Mydaorepository;
import com.capgemini.hub.rest.model.Training;

@Service
public class Myserviceimpl implements Myservice {

	@Autowired
	Mydaorepository dao;

	@Override
	public List<Training> getTrainings() {
		return dao.findAll();
	}
	@Override
	public Optional<Training> getTrainingById(int empid) {
		return dao.findById(empid);
	}
	@Override
	public Training addNewTraining(Training emp) {
		return dao.save(emp);
	}
	@Override
	public Training updateTraining(Training emp) {
		return dao.save(emp);
	}
	@Override
	public void deleteTrainingById(int empid) {
		dao.deleteById(empid);
	}
	@Override
	public void deleteAllTrainings() {
		dao.deleteAll();
	}
}