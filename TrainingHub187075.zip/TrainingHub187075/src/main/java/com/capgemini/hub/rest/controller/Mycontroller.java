package com.capgemini.hub.rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hub.rest.model.Training;
import com.capgemini.hub.rest.service.Myservice;

@RestController
public class Mycontroller {

	@Autowired
	Myservice service;

	@RequestMapping(value= "/training/all", method= RequestMethod.GET)
	public List<Training> getTrainings() {
		System.out.println(this.getClass().getSimpleName() + " - Get all trainings service is invoked.");
		return service.getTrainings();
	}

	@RequestMapping(value= "/training/{id}", method= RequestMethod.GET)
	public Training getTrainingById(@PathVariable int id) throws Exception {
		System.out.println(this.getClass().getSimpleName() + " - Get training details by id is invoked.");

		Optional<Training> emp =  service.getTrainingById(id);
		if(!emp.isPresent())
			throw new Exception("Could not find training with id- " + id);

		return emp.get();
	}

	@RequestMapping(value= "/training/add", method= RequestMethod.POST)
	public Training createTraining(@RequestBody Training newtraining) {
		System.out.println(this.getClass().getSimpleName() + " - Create new training method is invoked.");
		return service.addNewTraining(newtraining);
	}

	@RequestMapping(value= "/training/update/{id}", method= RequestMethod.PUT)
	public Training updateTraining(@RequestBody Training updtrng, @PathVariable int id) throws Exception {
		System.out.println(this.getClass().getSimpleName() + " - Update training details by id is invoked.");

		Optional<Training> trng =  service.getTrainingById(id);
		if (!trng.isPresent())
			throw new Exception("Could not find training with id- " + id);

		/* IMPORTANT - To prevent the overiding of the existing value of the variables in the database, 
		 * if that variable is not coming in the @RequestBody annotation object. */		
		if(updtrng.getName() == null || updtrng.getName().isEmpty())
			updtrng.setName(trng.get().getName());
		if(updtrng.getDuration() == null || updtrng.getDuration().isEmpty())
			updtrng.setDuration(trng.get().getDuration());
		if(updtrng.getFees() == 0)
			updtrng.setFees(trng.get().getFees());

		// Required for the "where" clause in the sql query template.
		updtrng.setId(id);
		return service.updateTraining(updtrng);
	}

	@RequestMapping(value= "/training/delete/{id}", method= RequestMethod.DELETE)
	public void deleteTrainingById(@PathVariable int id) throws Exception {
		System.out.println(this.getClass().getSimpleName() + " - Delete training by id is invoked.");

		Optional<Training> trng =  service.getTrainingById(id);
		if(!trng.isPresent())
			throw new Exception("Could not find training with id- " + id);

		service.deleteTrainingById(id);
	}

	@RequestMapping(value= "/training/deleteall", method= RequestMethod.DELETE)
	public void deleteAll() {
		System.out.println(this.getClass().getSimpleName() + " - Delete all trainings is invoked.");
		service.deleteAllTrainings();
	}
}